package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AddOrganizers_Path 
{

	public WebDriver driver;


	//Add Organizers
	By AddOrg = By.xpath("//button[normalize-space()='Add Organizers']");
	By FullName = By.xpath("//input[@placeholder='Enter the full name']");
	By EmailAdd = By.cssSelector("input[placeholder='Enter the email address']");
	By PhoneNo = By.xpath("//input[@placeholder='Enter the mobile number']");
	
	//Buttons
	By AddButton = By.xpath("//p[@class='text-center p-5 text-ft4 font-OpenSansSemiBold text-white cursor-pointer']");
	By CancelButton = By.xpath("//p[@class=' text-center p-5 text-ft4 font-OpenSansSemiBold cursor-pointer text-black-50']");
	By Okay = By.xpath("//button[normalize-space()='Okay']");
	
	//Error
	By NameError = By.xpath("//div[normalize-space()='Enter the name']");
	By EmailError = By.xpath("//div[normalize-space()='Enter valid email address']");
	By PhoneNoError = By.xpath("//div[normalize-space()='Enter the Phone no']");
	
	

	public AddOrganizers_Path (WebDriver driver) 
	{
		this.driver=driver;
	
	}
	public WebElement getAddOrg()
	{
		return driver.findElement(AddOrg);	
    }
	public WebElement getFullName()
	{
		return driver.findElement(FullName);	
    }
	public WebElement getEmailAdd()
	{
		return driver.findElement(EmailAdd);
	}
	public WebElement getPhoneNo()
	{
		return driver.findElement(PhoneNo);
	}
	public WebElement getAddButton()
	{
		return driver.findElement(AddButton);
	}
	public WebElement getCancelButton()
	{
		return driver.findElement(CancelButton);
	}
	public WebElement getOkay()
	{
		return driver.findElement(Okay);
	}
	public WebElement getNameError()
	{
		return driver.findElement(NameError);	
    }
	public WebElement getEmailError()
	{
		return driver.findElement(EmailError);
	}
	public WebElement getPhoneNoError()
	{
		return driver.findElement(PhoneNoError);

}
}
	

