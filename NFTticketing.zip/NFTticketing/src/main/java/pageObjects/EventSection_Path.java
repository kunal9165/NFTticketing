package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class EventSection_Path 
{
	public WebDriver driver;

	By Events = By.xpath("//p[normalize-space()='Events']");
	By SearchEvents = By.xpath("//input[contains(@placeholder,'Search events')]");
	By UpcomingE =By.xpath("//button[normalize-space()='Upcoming']");
	By PreviousE =By.xpath("//button[normalize-space()='Previous']");
	
	//No Data in table Placeholder
	By NoRecord = By.xpath("//div[contains(@class,'noRecordFound')]");
	

	public EventSection_Path (WebDriver driver) 
	{
		this.driver=driver;
	
	}
	public WebElement getEvents()
	{
		return driver.findElement(Events);	
    }
	public WebElement getSearchEvents()
	{
		return driver.findElement(SearchEvents);	
    }
	public WebElement getUpcomingE()
	{
		return driver.findElement(UpcomingE);
	}
	public WebElement getPreviousE()
	{
		return driver.findElement(PreviousE);	
		
	}
	public WebElement getNoRecord()
	{
		return driver.findElement(NoRecord);	
		
	}

}

