package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ForgotPassword_Path 
{
	public WebDriver driver;
	
	 
	By ForgotLink = By.cssSelector("a[href='/forget-password']");
	By Email = By.xpath("//input[@placeholder='Email Address']");
	By Send = By.xpath("//button[normalize-space()='Send']");
	By Proceed = By.xpath("//button[normalize-space()='Proceed']");
	
	//Error
	By EmailError =By.xpath("//div[@class='text-left']");
	
	

	
	
	public ForgotPassword_Path (WebDriver driver) 
	{
		this.driver=driver;
	
	}
	public WebElement getForgotLink()
	{
		return driver.findElement(ForgotLink);	
    }
	public WebElement getEmail()
	{
		return driver.findElement(Email);	
    }
	public WebElement getSend()
	{
		return driver.findElement(Send);	
    }
	public WebElement getEmailError()
	{
		return driver.findElement(EmailError);
	}
	public WebElement getProceed()
	{
		return driver.findElement(Proceed);
	}
}

