package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login_Path 
{
	public WebDriver driver;

	By Email = By.xpath("//input[@id='email']");
	By Password = By.xpath("//input[@id='password']");
	By Checkbox = By.xpath("//input[@id='checkbox']");
	By Submit = By.xpath("//button[normalize-space()='Sign in']");
	By Error = By.xpath("//div[@class='mt-6 h-7']");
	
	
	
	
	public Login_Path (WebDriver driver) 
	{
		this.driver=driver;
	
	}
	public WebElement getEmail()
	{
		return driver.findElement(Email);
	}
	public WebElement getPassword()
	{
		return driver.findElement(Password);
	}
	public WebElement getCheckbox()
	{
		return driver.findElement(Checkbox);
	}
	public WebElement getSubmit()
	{
		return driver.findElement(Submit);
	}
	public WebElement getError()
	{
		return driver.findElement(Error);
	}
}
