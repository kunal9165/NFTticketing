package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Notification_Path 
{
	public WebDriver driver;

	By NotificationIcon = By.xpath("//img[@class='mr-10 h-5 my-6 cursor-pointer ']");
	By ViewAll =By.xpath("//div[@class=' cursor-pointer bg-blue-50 h-10 w-62.5 flex justify-center items-center rounded-2xl text-ft2 text-Slate-100 ']");
	By ViewLess =By.xpath("//div[contains(@class,'cursor-pointer bg-blue-50 h-10 w-62.5 flex justify-center items-center rounded-2xl text-ft2 text-Slate-100')]");
	By Unread =By.xpath("//div[normalize-space()='Unread']");
	By Profile =By.xpath("//p[contains(@class,'font-OpenSansSemiBold text-ft3 text-darkGrey-100')]");
	By Logout =By.xpath("//div[contains(text(),'Logout')]");
	
	
	
	public Notification_Path (WebDriver driver) 
	{
		this.driver=driver;
	
	}
	
	public WebElement getNotificationIcon()
	{
		return driver.findElement(NotificationIcon);
		
    }
	public WebElement getViewAll()
	{
		return driver.findElement(ViewAll);
		
	}
	public WebElement getViewLess()
	{
		return driver.findElement(ViewLess);	
	}
	public WebElement getUnread()
	{
		return driver.findElement(Unread);
		
	}
	public WebElement getProfile()
	{
		return driver.findElement(Profile);	
	}
	public WebElement getLogout()
	{
		return driver.findElement(Logout);	
	}

}

