package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ProfileSetting_Path 
{
	public WebDriver driver;

	By PSetting = By.xpath("//p[contains(@class,'font-OpenSansSemiBold text-ft3 text-darkGrey-100')]");
	By AccountSetting =By.xpath("//div[contains(@class,'h-10 flex items-center pl-4 font-OpenSansRegular text-ft2 text-left text-darkGrey-100 cursor-pointer')]");
	
	By SName =By.xpath("//input[@placeholder='Enter your name']");
	
	By SOrganization =By.xpath("//input[contains(@placeholder,\"Enter organization's name\")]");
	
	By SDiscard =By.xpath("//button[normalize-space()='Discard']");
	By SUpdateButton = By.xpath("//button[normalize-space()='Update']");
	
	By SDashboard = By.xpath("//div[@class=' flex text-ft8 font-OpenSansSemiBold text-left text-black-50 justify-between items-center']");
	

	public ProfileSetting_Path (WebDriver driver) 
	{
		this.driver=driver;
	
	}
	
	public WebElement getPSetting()
	{
		return driver.findElement(PSetting);	
    }
	public WebElement getAccountSetting()
	{
		return driver.findElement(AccountSetting);
	}
	public WebElement getSName()
	{
		return driver.findElement(SName);	
	}
	public WebElement getSOrganization()
	{
		return driver.findElement(SOrganization);	
	}
	public WebElement getSDiscard()
	{
		return driver.findElement(SDiscard);
	}
	public WebElement getSUpdateButton()
	{
		return driver.findElement(SUpdateButton);
	}
	public WebElement getSDashboard()
	{
		return driver.findElement(SDashboard);
	}
}

