package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WhiteList_Path 
{
	public WebDriver driver;

	By WhiteList = By.xpath("//p[normalize-space()='Whitelist']");
	By SearchOrganizers = By.xpath("//input[@placeholder='Search organizers']");
	By EditIcon =By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div/div[3]/table/tbody/tr[2]/td[5]/img");
	By Edit = By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div/div[3]/table/tbody/tr[2]/td[5]/div/div[1]");
	
	//Update Organizers
	By FullName = By.xpath("//input[contains(@placeholder,'Enter the full name')]");
	By Phoneno = By.xpath("//input[@placeholder='Enter the mobile number']");
	
	
	//Buttons
	By Cancel = By.xpath("//p[@class=' text-center p-5 text-ft4 font-OpenSansSemiBold cursor-pointer text-black-50']");
	By Update = By.xpath("//p[@class='text-center p-5 text-ft4 font-OpenSansSemiBold text-white cursor-pointer']");
	
	By Okay = By.xpath("//button[normalize-space()='Okay']");
	
	//Dashboard
	By Dashboard = By.xpath("//p[normalize-space()='Dashboard']");
	
	

	public WhiteList_Path (WebDriver driver) 
	{
		this.driver=driver;
	
	}
	public WebElement getWhiteList()
	{
		return driver.findElement(WhiteList);	
    }
	public WebElement getSearchOrganizers()
	{
		return driver.findElement(SearchOrganizers);	
    }
	public WebElement getEditIcon()
	{
		return driver.findElement(EditIcon);
	}
	public WebElement getEdit()
	{
		return driver.findElement(Edit);
	}
	public WebElement getFullName()
	{
		return driver.findElement(FullName);
	}
	public WebElement getPhoneno()
	{
		return driver.findElement(Phoneno);
	}
	public WebElement getCancel()
	{
		return driver.findElement(Cancel);
	}
	public WebElement getUpdate()
	{
		return driver.findElement(Update);
	}
	public WebElement getOkay()
	{
		return driver.findElement(Okay);
	}
	public WebElement getDashboard()
	{
		return driver.findElement(Dashboard);
	}

}

