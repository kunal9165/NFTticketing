package Testcases;

import java.awt.AWTException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pageObjects.ProfileSetting_Path;
import pageObjects.WhiteList_Path;
import pageObjects.Login_Path;
import pageObjects.Notification_Path;
import pageObjects.AddOrganizers_Path;
import pageObjects.EventSection_Path;
import pageObjects.ForgotPassword_Path;
import resources.base;

@Test
public class AllTestcases extends base
{
	public WebDriver driver;
	public static Logger log =LogManager.getLogger(base.class.getName());
	
	@BeforeTest
	@Parameters("browserName")
	
	public void Initialize(String browserName) throws IOException, InterruptedException, AWTException
	{
		//prop.setProperty("browser", browserName);
		
	driver=initializeDriver(browserName);
	log.info("Driver is initialized");
	driver.manage().window().maximize();
	log.info("Browser Window Maximized");
	driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	driver.get(prop.getProperty("url"));
	log.info("Navigated to Loginin page");
	driver.manage().deleteAllCookies();
	
		
	}
	

	//Login With Invalid Email Id
	@Test (priority=1,description="Login With Invalid Email Id")
	public void InvalidEmail() throws IOException, InterruptedException
	{
		//driver.get(prop.getProperty("url"));
		log.info("Test with Invalid Email Id");
		Login_Path LP = new Login_Path(driver);
		
		LP.getEmail().sendKeys("akashku@leewayhertz");
		LP.getPassword().sendKeys("Admin@123");
		LP.getCheckbox().click();
		LP.getSubmit().click();
		Assert.assertEquals(LP.getError().getText(), "Username and password does not match");
		System.out.println(LP.getError().getText());
		
		
		Thread.sleep(3000);
		
	}
	
	//Login With Invalid Password
	@Test (priority=2,description="Login With Invalid Password")
	public void InvalidPassword() throws IOException, InterruptedException
	{
		driver.get(prop.getProperty("url"));
		log.info("Test with Invalid Password");
		Login_Path LP = new Login_Path(driver);
		
		LP.getEmail().sendKeys("akashku@leewayhertz.com");
		LP.getPassword().sendKeys("Leeway123");
		LP.getCheckbox().click();
		LP.getSubmit().click();
		Assert.assertEquals(LP.getError().getText(), "Username and password does not match");
		System.out.println(LP.getError().getText());
		
		
		Thread.sleep(3000);
		
	}
	
	//Login With valid Email and password
	@Test (priority=3,description="Login With Valid Email and Password")
	public void ValidLogins() throws IOException, InterruptedException
	{
		driver.get(prop.getProperty("url"));
		log.info("Test with Valid Logins");
		Login_Path LP = new Login_Path(driver);
		
		LP.getEmail().sendKeys("akashku@leewayhertz.com");
		LP.getPassword().sendKeys("Admin@123");
		LP.getCheckbox().click();
		LP.getSubmit().click();
		
		
		Thread.sleep(4000);
	}
	
	
	//Add Organizers With No Data
	@Test (priority=4,description="Add Organizer With No Data")
	public void AddOrganizerNoData() throws IOException, InterruptedException
	{
			
		log.info("Add Organizers With No Data");
		
		
		AddOrganizers_Path AO = new AddOrganizers_Path(driver);
		
		
		AO.getAddOrg().click();	
		AO.getFullName().sendKeys("");
		AO.getEmailAdd().sendKeys("");
		AO.getPhoneNo().sendKeys("");
		AO.getAddButton().click();
		
		Assert.assertEquals(AO.getNameError().getText(), "Enter the name");
		System.out.println(AO.getNameError().getText());
		
		Assert.assertEquals(AO.getEmailError().getText(), "Enter valid email address");
		System.out.println(AO.getEmailError().getText());
		
		Assert.assertEquals(AO.getPhoneNoError().getText(), "Enter the Phone no");
		System.out.println(AO.getPhoneNoError().getText());
		
		
		Thread.sleep(5000);
	}
	
	
	//Add Organizers 
	@Test (priority=5,description="Add Organizer")
	public void AddOrganizer() throws IOException, InterruptedException
	{
			
		log.info("Add Organizer");
		AddOrganizers_Path AO = new AddOrganizers_Path(driver);
			
				
		AO.getFullName().sendKeys("Kunal Gupta");
		AO.getEmailAdd().sendKeys("kunal@leewayhertz.com");
		AO.getPhoneNo().sendKeys("9340280062");
		
		Thread.sleep(2000);
		
		//AO.getAddButton().click();
		Thread.sleep(3000);
		//AO.getOkay().click();
		
		AO.getCancelButton().click();
			
		//Thread.sleep(4000);		
		
	}
	
	
	//Super Admin Profile Setting 
	@Test (priority=6,description="Account Setting")
	public void AccountSetting() throws IOException, InterruptedException
	{
			
		log.info("Account Setting");
		ProfileSetting_Path  PS = new ProfileSetting_Path (driver);
			
				
		PS.getPSetting().click();
		PS.getAccountSetting().click();
		
		Thread.sleep(2000);
		
		PS.getSName().clear();
		PS.getSName().sendKeys("Kunal");	
		

		
		Thread.sleep(2000);
		PS.getSOrganization().clear();
		Thread.sleep(2000);
		PS.getSOrganization().sendKeys("leewayhertz");
		
		Thread.sleep(2000);
		
		//Discard Button
		PS.getSDiscard().click();
		
		
		//Update Button
		//PS.getSUpdateButton().click();
		
		Thread.sleep(2000);
		
		PS.getSDashboard().click();
		
	}
	     
	//Event Section verify all the search function
		@Test (priority=7,description="Event Section")
		public void EventSection() throws IOException, InterruptedException
		{
				
			log.info("Event Section");
			EventSection_Path  ES = new EventSection_Path (driver);
			
			
			//Search with valid data	
			ES.getEvents().click();
			Thread.sleep(5000);	
			ES.getSearchEvents().sendKeys("Feel The Music");
			Thread.sleep(4000);
			
			
			//Search with Invalid data
			ES.getSearchEvents().sendKeys("dajddbahdvah");	
			
	
			//Search with valid data 
			ES.getUpcomingE().click();
			Thread.sleep(4000);	
			ES.getSearchEvents().sendKeys("Whole");
			Thread.sleep(3000);
			
			//Search with invalid data
			ES.getSearchEvents().sendKeys("whdwhdwcvwh");
			
	
			//Search with valid data 
			ES.getPreviousE().click();
			Thread.sleep(4000);
			ES.getSearchEvents().sendKeys("Light Event");
			Thread.sleep(3000);
			
			//Search with invalid data
			ES.getSearchEvents().sendKeys("djjbschubcchcc");
			
		
			
			
		}
		
		//White List Section verify all the function
		@Test (priority=8,description="White List Search")
		public void WhiteListSearch() throws IOException, InterruptedException
			{
					
				log.info("White List Search");
				WhiteList_Path  WL = new WhiteList_Path  (driver);
					
						
				WL.getWhiteList().click();
				Thread.sleep(3000);
				
				WL.getSearchOrganizers().sendKeys("Kunal");
				Thread.sleep(5000);
				
				WL.getEditIcon().click();
				Thread.sleep(2000);
				
				WL.getEdit().click();
				
				
	}
		
		//White List Section Update The Organizer
		@Test (priority=9,description="White List Update")
		public void WhiteListUpdate() throws IOException, InterruptedException
	{
						
		log.info("White List Update");
		WhiteList_Path  WL = new WhiteList_Path  (driver);
								
		WL.getFullName().clear();
		WL.getFullName().sendKeys("Test");
		WL.getPhoneno().clear();
		WL.getPhoneno().sendKeys("9191919191");
		
		Thread.sleep(3000);
		
		//cancel
		//WL.getCancel().click();
		
		
		//Update organizer
		WL.getUpdate().click();
		
		
//		Thread.sleep(3000);
        WL.getOkay().click();
			
		Thread.sleep(3000);
		WL.getDashboard().click();
		
		
	}
		
		//Notification section and Logout
		@Test (priority=10,description="Notification")
		public void Notification() throws IOException, InterruptedException
	{
						
		log.info("Notification");
		Notification_Path  N = new Notification_Path  (driver);
								
		N.getNotificationIcon().click();
//		N.getViewAll().click();
//		Thread.sleep(3000);
//		N.getViewLess().click();
		Thread.sleep(2000);
		N.getUnread().click();
		Thread.sleep(2000);
		N.getProfile().click();
		Thread.sleep(1000);
		N.getLogout().click();
		Thread.sleep(3000);
		
	}
		//Forgot Password with wrong Data and With Correct Data
		@Test (priority=11,description="Forgot Password")
		public void ForgotPassword() throws IOException, InterruptedException
	{
						
		log.info("Forgot Password");
		ForgotPassword_Path  F = new ForgotPassword_Path  (driver);
		
		
	    F.getForgotLink().click();
	    
	    Thread.sleep(2000);
	    F.getEmail().sendKeys("kunal");
	    F.getSend().click();
	    
	    Thread.sleep(5000);
	    F.getEmail().clear();
	    F.getEmail().sendKeys("akashku@leewayhertz.com");
	    F.getSend().click();
	    F.getProceed().click();
		
		
	}

	}
		
		
		
	
	
	
	

